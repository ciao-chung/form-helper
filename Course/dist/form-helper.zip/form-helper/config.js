export default {
  project: '表單助手',
}